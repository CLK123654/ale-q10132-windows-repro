import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const reportsDir = path.join(root, "output", "reports");

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === "\"" && text[index + 1] === "\"") {
        cell += "\"";
        index += 1;
      } else if (char === "\"") quoted = false;
      else cell += char;
    } else if (char === "\"") quoted = true;
    else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else cell += char;
  }
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }
  const headers = rows.shift() ?? [];
  return rows
    .filter((values) => values.some((value) => value !== ""))
    .map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

function splitAttributes(text) {
  const parts = [];
  let current = "";
  let quoted = false;
  for (const char of text) {
    if (char === "\"") quoted = !quoted;
    if (char === "," && !quoted) {
      parts.push(current);
      current = "";
    } else current += char;
  }
  parts.push(current);
  return Object.fromEntries(parts.map((part) => {
    const separator = part.indexOf("=");
    if (separator < 1) throw new Error(`无效HLS属性：${part}`);
    return [part.slice(0, separator), part.slice(separator + 1).replace(/^\"|\"$/g, "")];
  }));
}

function parseMaster(text) {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const variants = [];
  for (let index = 0; index < lines.length; index += 1) {
    if (!lines[index].startsWith("#EXT-X-STREAM-INF:")) continue;
    const attributes = splitAttributes(lines[index].slice("#EXT-X-STREAM-INF:".length));
    const uri = lines[index + 1];
    const resolution = /^(\d+)x(\d+)$/.exec(attributes.RESOLUTION ?? "");
    const bandwidth = Number(attributes.BANDWIDTH);
    if (!uri || uri.startsWith("#") || !resolution || !Number.isFinite(bandwidth) || !attributes.CODECS) {
      throw new Error("master中的variant信息不完整");
    }
    variants.push({
      profile: `${resolution[2]}p`,
      bandwidth,
      resolution: attributes.RESOLUTION,
      codec: attributes.CODECS,
      uri
    });
  }
  return variants;
}

function parseVariant(text) {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const mediaSequence = Number(lines.find((line) => line.startsWith("#EXT-X-MEDIA-SEQUENCE:"))?.split(":")[1] ?? 0);
  const segments = [];
  for (let index = 0; index < lines.length; index += 1) {
    if (!lines[index].startsWith("#EXTINF:")) continue;
    const duration = Number(lines[index].slice("#EXTINF:".length).split(",")[0]);
    const uri = lines[index + 1];
    if (!Number.isFinite(duration) || !uri || uri.startsWith("#")) throw new Error("EXTINF与片段URI不成对");
    segments.push({ duration, uri });
  }
  return { mediaSequence, segments };
}

function expectedSegmentUri(sampleUri, sequence) {
  const match = /^(.*?)(\d+)(\.[^./]+)$/.exec(sampleUri);
  return match ? `${match[1]}${String(sequence).padStart(match[2].length, "0")}${match[3]}` : "";
}

function csvEscape(value) {
  const text = String(value ?? "");
  return /[\",\n]/.test(text) ? `\"${text.replace(/\"/g, "\"\"")}\"` : text;
}

function toCsv(headers, rows) {
  return `${[headers.join(","), ...rows.map((row) => headers.map((header) => csvEscape(row[header])).join(","))].join("\n")}\n`;
}

function profileRank(profile, requiredProfiles) {
  const index = requiredProfiles.indexOf(profile);
  return index >= 0 ? index : requiredProfiles.length;
}

const jobs = parseCsv(await fs.readFile(path.join(root, "data", "encode_jobs.csv"), "utf8"))
  .sort((left, right) => left.asset_id.localeCompare(right.asset_id));
if (new Set(jobs.map((job) => job.asset_id)).size !== jobs.length) throw new Error("asset_id重复");
const policy = JSON.parse(await fs.readFile(path.join(root, "rules", "hls_publish_policy.json"), "utf8"));
const requiredProfiles = policy.required_profiles;
const reasonRank = (reason) => {
  const index = policy.requeue_reason_order.indexOf(reason);
  if (index < 0) throw new Error(`策略未定义原因：${reason}`);
  return index;
};
const compareIssues = (left, right) => reasonRank(left.reason) - reasonRank(right.reason)
  || profileRank(left.profile, requiredProfiles) - profileRank(right.profile, requiredProfiles)
  || left.source.localeCompare(right.source);

const assetRows = [];
const variantRows = [];
const requeueRows = [];
const ladderRows = [];

for (const job of jobs) {
  const assetDir = path.join(root, "playlists", job.asset_id);
  const masterRelative = `playlists/${job.asset_id}/master.m3u8`;
  const variants = parseMaster(await fs.readFile(path.join(assetDir, "master.m3u8"), "utf8"))
    .sort((left, right) => profileRank(left.profile, requiredProfiles) - profileRank(right.profile, requiredProfiles));
  if (new Set(variants.map((variant) => variant.profile)).size !== variants.length) throw new Error(`${job.asset_id}存在重复profile`);
  const byProfile = new Map(variants.map((variant) => [variant.profile, variant]));
  const issues = [];
  const profileIssues = new Map();
  const remember = (issue) => {
    issues.push(issue);
    const list = profileIssues.get(issue.profile) ?? [];
    list.push(issue);
    profileIssues.set(issue.profile, list);
  };
  for (const profile of requiredProfiles) {
    if (!byProfile.has(profile)) remember({ reason: "missing_profile", profile, source: masterRelative, expectedSegment: "" });
  }

  const expectedDuration = Number(job.expected_duration_seconds);
  const expectedSegmentCount = Math.round(expectedDuration / policy.target_duration_seconds);
  const currentRows = [];
  for (const variant of variants) {
    const source = `playlists/${job.asset_id}/${variant.uri}`;
    const parsed = parseVariant(await fs.readFile(path.join(assetDir, variant.uri), "utf8"));
    const totalDuration = parsed.segments.reduce((sum, segment) => sum + segment.duration, 0);
    const maxSegment = parsed.segments.length ? Math.max(...parsed.segments.map((segment) => segment.duration)) : 0;
    const actualUris = new Set(parsed.segments.map((segment) => segment.uri));
    let missingExpected = "";
    for (let index = 0; index < expectedSegmentCount; index += 1) {
      const expected = expectedSegmentUri(parsed.segments[0]?.uri ?? "", parsed.mediaSequence + index);
      if (expected && !actualUris.has(expected)) {
        missingExpected = expected;
        break;
      }
    }
    if (missingExpected) remember({ reason: "missing_segment", profile: variant.profile, source, expectedSegment: missingExpected });
    else if (Math.abs(totalDuration - expectedDuration) > policy.total_duration_tolerance_seconds
      || parsed.segments.some((segment) => Math.abs(segment.duration - policy.target_duration_seconds) > policy.segment_duration_tolerance_seconds)) {
      remember({ reason: "duration_drift", profile: variant.profile, source, expectedSegment: "" });
    }
    if (!variant.codec.startsWith(policy.codec_prefix)) remember({ reason: "codec_mismatch", profile: variant.profile, source: masterRelative, expectedSegment: "" });
    const minimum = Number(policy.minimum_bandwidth[variant.profile]);
    const maximum = Number(policy.maximum_bandwidth[variant.profile]);
    if (!Number.isFinite(minimum) || !Number.isFinite(maximum) || variant.bandwidth < minimum || variant.bandwidth > maximum) {
      remember({ reason: "bandwidth_out_of_range", profile: variant.profile, source: masterRelative, expectedSegment: "" });
    }
    currentRows.push({
      asset_id: job.asset_id,
      profile: variant.profile,
      source_playlist: source,
      bandwidth: variant.bandwidth,
      resolution: variant.resolution,
      codec: variant.codec,
      segment_count: parsed.segments.length,
      total_duration_seconds: totalDuration.toFixed(3),
      max_segment_seconds: maxSegment.toFixed(3),
      playlist_status: ""
    });
  }

  let ladderProblem = "";
  for (let index = 1; index < requiredProfiles.length; index += 1) {
    const previous = byProfile.get(requiredProfiles[index - 1]);
    const current = byProfile.get(requiredProfiles[index]);
    if (previous && current && current.bandwidth <= previous.bandwidth) {
      ladderProblem ||= current.profile;
      remember({ reason: "ladder_not_increasing", profile: current.profile, source: masterRelative, expectedSegment: "" });
    }
  }
  for (const row of currentRows) row.playlist_status = [...(profileIssues.get(row.profile) ?? [])].sort(compareIssues)[0]?.reason ?? "ok";
  variantRows.push(...currentRows);

  const cells = requiredProfiles.map((profile) => byProfile.has(profile) ? String(byProfile.get(profile).bandwidth) : "missing");
  const bandwidths = cells.map((value, index) => {
    if (index === 0) return value;
    const previous = Number(cells[index - 1]);
    const current = Number(value);
    return `${Number.isFinite(previous) && Number.isFinite(current) && current <= previous ? ">" : "<"}${value}`;
  }).join("");
  ladderRows.push({
    asset_id: job.asset_id,
    profile_order: requiredProfiles.join("<"),
    bandwidths,
    ladder_status: requiredProfiles.some((profile) => !byProfile.has(profile))
      ? "missing_profile"
      : ladderProblem
        ? "ladder_not_increasing"
        : issues.some((issue) => issue.reason === "bandwidth_out_of_range")
          ? "bandwidth_out_of_range"
          : "ok"
  });

  const primary = [...issues].sort(compareIssues)[0];
  if (primary) {
    const action = policy.requeue_actions[primary.reason];
    if (!action) throw new Error(`策略缺少动作：${primary.reason}`);
    requeueRows.push({
      asset_id: job.asset_id,
      profile: primary.profile,
      reason: primary.reason,
      source_playlist: primary.source,
      expected_segment: primary.expectedSegment,
      action
    });
  }
  assetRows.push({
    asset_id: job.asset_id,
    expected_profiles: requiredProfiles.join("|"),
    found_profiles: requiredProfiles.filter((profile) => byProfile.has(profile)).join("|"),
    publish_decision: primary ? "hold_requeue" : "publish",
    primary_reason: primary?.reason ?? "ready",
    playable_variant_count: variants.filter((variant) => !(profileIssues.get(variant.profile)?.length)).length,
    requeue_count: primary ? 1 : 0
  });
}

await fs.mkdir(reportsDir, { recursive: true });
await fs.writeFile(path.join(reportsDir, "asset_publish_matrix.csv"), toCsv(
  ["asset_id", "expected_profiles", "found_profiles", "publish_decision", "primary_reason", "playable_variant_count", "requeue_count"],
  assetRows
));
await fs.writeFile(path.join(reportsDir, "variant_playlist_audit.csv"), toCsv(
  ["asset_id", "profile", "source_playlist", "bandwidth", "resolution", "codec", "segment_count", "total_duration_seconds", "max_segment_seconds", "playlist_status"],
  variantRows
));
await fs.writeFile(path.join(reportsDir, "segment_requeue.csv"), toCsv(
  ["asset_id", "profile", "reason", "source_playlist", "expected_segment", "action"],
  requeueRows
));
await fs.writeFile(path.join(reportsDir, "bandwidth_ladder.csv"), toCsv(
  ["asset_id", "profile_order", "bandwidths", "ladder_status"],
  ladderRows
));
