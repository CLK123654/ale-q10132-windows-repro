import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const jobsText = await fs.readFile(path.join(root, "data", "encode_jobs.csv"), "utf8");
const policy = JSON.parse(await fs.readFile(path.join(root, "rules", "hls_publish_policy.json"), "utf8"));

// TODO: 解析发布任务、master与variant播放列表，并按策略生成四份业务报告。
console.log(`待处理资产${jobsText.split(/\r?\n/).filter(Boolean).length - 1}个，必需profile${policy.required_profiles.length}个`);
