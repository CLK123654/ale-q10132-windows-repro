# HLS发布包放行核对

本目录保存一批脱敏短视频发布任务、HLS播放列表和放行策略。发布值班使用完成版Node.js程序检查profile、片段、时长、编码与码率，转码平台根据重投报告处理不合格资产。

data/encode_jobs.csv给出资产及预期时长。rules/hls_publish_policy.json定义profile要求、时长容差、编码前缀、码率范围、重投原因顺序和动作。playlists按资产保存master与variant播放列表，master中的URI决定实际读取文件。starter/audit_hls_publish.mjs是待完成源码。

将完成版保存为src/audit_hls_publish.mjs，在input_data中运行npm run process:hls。程序需要生成以下文件：

output/src/audit_hls_publish.mjs
output/reports/asset_publish_matrix.csv
output/reports/variant_playlist_audit.csv
output/reports/segment_requeue.csv
output/reports/bandwidth_ladder.csv

任务支持Windows11、macOS和Linux，需要Node.js24LTS，不使用第三方npm包。运行期间不连接转码、对象存储或CDN服务。
