import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { spawnSync } from "node:child_process";

const root = process.cwd();
const sourcePath = path.join(root, "src", "audit_hls_publish.mjs");
const outputRoot = path.join(root, "output");
const outputSource = path.join(outputRoot, "src", "audit_hls_publish.mjs");

async function requirePath(relative) {
  try {
    await fs.access(path.join(root, relative));
  } catch {
    throw new Error(`缺少必需材料：${relative}`);
  }
}

async function filesUnder(directory, prefix = "") {
  const result = [];
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) result.push(...await filesUnder(path.join(directory, entry.name), relative));
    else result.push(relative);
  }
  return result.sort();
}

try {
  for (const relative of [
    "data/encode_jobs.csv",
    "rules/hls_publish_policy.json",
    "playlists",
    "src/audit_hls_publish.mjs"
  ]) await requirePath(relative);

  await fs.rm(outputRoot, { recursive: true, force: true });
  await fs.mkdir(path.dirname(outputSource), { recursive: true });
  await fs.copyFile(sourcePath, outputSource);
  const child = spawnSync(process.execPath, [outputSource], {
    cwd: root,
    encoding: "utf8",
    timeout: 60000,
    windowsHide: true
  });
  if (child.error) throw child.error;
  if (child.status !== 0) throw new Error(child.stderr || child.stdout || `完成版返回${child.status}`);

  const expected = [
    "reports/asset_publish_matrix.csv",
    "reports/bandwidth_ladder.csv",
    "reports/segment_requeue.csv",
    "reports/variant_playlist_audit.csv",
    "src/audit_hls_publish.mjs"
  ];
  const actual = await filesUnder(outputRoot);
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error(`交付文件集合不符：${actual.join("|")}`);
  }
  process.stdout.write("HLS发布包放行结果已生成\n");
} catch (error) {
  await fs.rm(outputRoot, { recursive: true, force: true });
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 2;
}
